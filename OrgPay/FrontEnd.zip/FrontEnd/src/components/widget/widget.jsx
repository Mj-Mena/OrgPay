import "./widget.css"

const Widget = () => {
    return(
        <div className="widget">
            <div className="left">BALANCE:</div>
                <span className="money">PHP</span>
                <span className="amount">999,999.00</span>

        </div>
    )
}

export default Widget