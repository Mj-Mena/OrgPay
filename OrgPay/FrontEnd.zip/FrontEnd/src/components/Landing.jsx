import First from "./First";
import Second from "./Second";
import Third from "./Third";
import Last from "./Last";
import Navig from "./Navig";
function Landing() {
  return (
    <>
      <Navig />
      <First />
      <Second />
      <Third />
      <Last />
    </>
  );
}

export default Landing;
